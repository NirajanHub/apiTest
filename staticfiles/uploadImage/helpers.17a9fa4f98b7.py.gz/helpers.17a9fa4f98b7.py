def modify_input_for_multiple_files(category, image):
    dict = {}
    dict['category'] = category
    dict['images'] = image
    return dict
